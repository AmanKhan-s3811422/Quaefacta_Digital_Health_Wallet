# QueafactaHealthMk2 Frontend

Ensure that you are in the FrontEnd/queafacta folder.

Run the command `npm install`.

Then run the command `npm start`.

The app should now be running!
