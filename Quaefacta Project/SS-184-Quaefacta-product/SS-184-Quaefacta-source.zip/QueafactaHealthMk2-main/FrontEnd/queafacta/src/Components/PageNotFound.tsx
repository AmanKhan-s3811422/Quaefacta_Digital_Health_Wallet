const PageNotFound = () => {

    // Renders no page found page
    return (
        <div className="PageNotFound">
            <h1>This page does not exist</h1>
        </div>
    );
}

export default PageNotFound;