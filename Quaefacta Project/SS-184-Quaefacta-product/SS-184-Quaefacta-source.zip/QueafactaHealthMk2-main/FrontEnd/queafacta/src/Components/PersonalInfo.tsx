import FormPersonalInfo from "../Forms/FormPersonalInfo";

export default function PersonalInfo(props: any) {
    return (
        <div>
            <FormPersonalInfo />
        </div>
    );
}