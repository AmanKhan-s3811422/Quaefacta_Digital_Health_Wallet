import FormMedicalProfile from "../Forms/FormMedicalProfile";

export default function UpdateMedicalProfile(props: any) {
    return (
        <div>
            <FormMedicalProfile />
        </div>
    );
}