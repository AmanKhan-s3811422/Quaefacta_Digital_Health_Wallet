
export const API_URL = "http://localhost:8080/api/";

export const MAX_MYSQL_TEXT_LENGTH:number = 65535;