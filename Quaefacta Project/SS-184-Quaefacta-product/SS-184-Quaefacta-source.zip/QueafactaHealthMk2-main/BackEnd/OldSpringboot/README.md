# QueafactaHealthMk2 Backend

https://dev.mysql.com/downloads/installer/

You will need to have MySQL installed and running on your system.

Ensure that the credentials that you have are correct.

Run the `BackEnd\OldSpringboot\src\main\java\com\quaefactahealth\vaxapp\VaccineApplication.java` file.

Your backend should now be up and running!
