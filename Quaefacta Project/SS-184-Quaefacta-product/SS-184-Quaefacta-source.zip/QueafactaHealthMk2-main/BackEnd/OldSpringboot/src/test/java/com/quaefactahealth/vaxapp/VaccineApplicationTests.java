package com.quaefactahealth.vaxapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccineApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
