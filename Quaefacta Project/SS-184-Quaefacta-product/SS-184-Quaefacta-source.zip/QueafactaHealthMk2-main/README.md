# QueafactaHealthMk2
Semester 2, 2022  
Project Team:  
Aman Khan           - s3811422@student.rmit.edu.au  
Richard Forsey      - s3857811@student.rmit.edu.au  
Quoc Tran           - s3827826@student.rmit.edu.au  
Jack Allen          - s3832293@student.rmit.edu.au  
Jiajie "Sheldon" Lu - s3779102@student.rmit.edu.au  
Capstone Mentor:  
Sumedh Shriram      - sumedh.shriram@rmit.edu.au  

This will be a multi-folder project. See the README for each folder for the respective instructions.  
**Be very careful about which folder you are in with terminal commands!**

Git structure will follow this pattern.
main > development > feature/**

Frontend: React-TS with React-Boostrap library components. 
Backend: Springboot REST API to SQL DB w/ document storage on S3 bucket.  
Orchestration: Terraform, Ansible, Makefile. 
